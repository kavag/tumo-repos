function setup() {
    var socket = io();
    var side = 24;
    var matrix = [];

    let grassCountElement = document.getElementById('grassCount');
    let grassEaterCountElement = document.getElementById('grassEaterCount');

    let grassEaterEaterCount = document.getElementById('grassEatreCount');
    let waterCountElement = document.getElementById('waterCount');
    let fireCountElement = document.getElementById('fireCount');

    socket.on("data", drawCreatures);

    function drawCreatures(data) {
        matrix = data.matrix;

        // grassCountElement.innerText = data.grassCounter;
        // grassEaterCountElement.innerText = data.eaterCounter;

        // grassEaterEaterCount.innerText = data.eatrCounter;
        // waterCountElement.innerText = data.waterCounter;
        // fireCountElement.innerText = data.fireCounter;

        createCanvas(matrix[0].length * side, matrix.length * side)
        background('#acacac');

        for (var i = 0; i < matrix.length; i++) {
            for (var j = 0; j < matrix[i].length; j++) {
                if (matrix[i][j] == 1) {
                    fill("green");
                    rect(j * side, i * side, side, side);
                } else if (matrix[i][j] == 2) {
                    fill("orange");
                    rect(j * side, i * side, side, side);
                } else if (matrix[i][j] == 0) { // stage
                    fill('#acacac');
                    rect(j * side, i * side, side, side);
                } else if (matrix[i][j] == 3) {
                    fill('red');
                    rect(j * side, i * side, side, side);
                } else if (matrix[i][j] == 4) {
                    fill('blue');
                    rect(j * side, i * side, side, side);
                } else if (matrix[i][j] == 5) {
                    fill('yellow');
                    rect(j * side, i * side, side, side);
                }
            }
        }
    }
}